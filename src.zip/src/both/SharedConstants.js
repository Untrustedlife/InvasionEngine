export const entityTypes = Object.freeze({
  entity: "entity",
  ball: "ball",
  sparkle: "sparkle",
  barrel: "barrel",
  food: "food",
  key: "key",
});
